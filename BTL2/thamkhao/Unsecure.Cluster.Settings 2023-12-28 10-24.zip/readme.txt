
The new server is available at: http://26.200.45.220:8080
The current node ('A') has already been configured and requires no further action on your part.

You are setting up a cluster. The cluster topology and node addresses have already been configured.
The next step is to download a new RavenDB server for each of the other nodes.

When you enter the Setup Wizard on a new node, please choose 'Use Setup Package'.
Do not try to start a new setup process again in this new node, it is not supported.
You will be asked to upload the zip file which was just downloaded.
The new server node will join the already existing cluster.

When the Setup Wizard is done and the new node was restarted, the cluster will automatically detect it. 
There is no need to manually add it again from the studio. Simply access the 'Cluster' view and 
observe the topology being updated.
